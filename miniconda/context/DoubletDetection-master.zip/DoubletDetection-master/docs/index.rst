.. DoubletDetection documentation master file, created by
   sphinx-quickstart on Wed Jul  3 15:04:18 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 5
   :caption: Contents:


   doubletdetection
   plot


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
