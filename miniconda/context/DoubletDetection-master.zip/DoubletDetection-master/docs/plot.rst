Plot
====================

.. currentmodule:: doubletdetection

.. autosummary::
   :toctree: reference/

   plot.convergence
   plot.threshold
