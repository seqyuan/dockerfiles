DoubletDetection
====================

.. currentmodule:: doubletdetection

.. autosummary::
   :toctree: reference/

   BoostClassifier
   BoostClassifier.fit
   BoostClassifier.doublet_score
   BoostClassifier.predict
